#define QT_FEATURE_widgettextcontrol 1
#define QT_FEATURE_effects 1
#define QT_FEATURE_gtk3 -1
#define QT_FEATURE_style_android -1
#define QT_FEATURE_style_fusion 1
#define QT_FEATURE_style_mac 1
#define QT_FEATURE_style_windows 1
#define QT_FEATURE_style_windowsvista -1
